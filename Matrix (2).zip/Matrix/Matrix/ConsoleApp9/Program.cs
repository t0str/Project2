﻿using System;
using System.Globalization;
using System.IO;

// Заранее извиняюсь за свой английский в большинстве случаев пользовался переводчиком, чтобы называть функции
// и переменные.
// Комментарии специально для любителей, чтобы он был перед кодом, который поясняет, написаны именно так.
namespace ConsoleApp9
{
    class Program
    {

        /// <summary>
        /// Функция рандомно генерирует матрицу заданных размеров.
        /// </summary>
        /// <param name="numberString"> Количество строк, которое должно быть в матрице. </param>
        /// <param name="numberColumns"> Количество столбцов, которое должно быть в матрице. </param>
        /// <returns> Возвращает корректную рандомно сгенерированную матрицу. </returns>
        static double[,] Random(int numberString, int numberColumns)
        {
            var matrix = new double[numberString, numberColumns];
            var rand = new Random();
            // Заполняем массив рандомными числами от 0 до 10.
            for (int i = 0; i < numberString; i++)
            {
                for (int j = 0; j < numberColumns; j++)
                {
                    matrix[i, j] = (int)(rand.NextDouble() * 100) / 10.0;
                }
            }
            // Выводим массив заполненный рандомными числами, чтобы пользователь понял, какая матрица сгенерировалась.
            for (int i = 0; i < numberString; i++)
            {
                for (int j = 0; j < numberColumns - 1; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine(matrix[i, numberColumns - 1]);
            }
            return matrix;
        }

        /// <summary>
        /// Функция позволяет вводить пользователю матрицу заданного размера с использованием ограничений на ввод.
        /// </summary>
        /// <param name="numberString"> Количество строк, которое должно быть в матрице. </param>
        /// <param name="numberColumns"> Количество столбцов, которое должно быть в матрице. </param>
        /// <returns> Возвращает корректную матрицу, введённую пользователем. </returns>
        static double[,] Input(int numberString, int numberColumns)
        {
            Console.WriteLine("Введите элементы матрицы:");
            bool exit;
            var inputMatrix = new double[numberString, numberColumns];
            string[] inputString;
            for (int i = 0; i < numberString; i++)
            {
                do
                {
                    exit = true;
                    inputString = Console.ReadLine().Split(' ');
                    // Проверка верное ли количество значений введенно.
                    if (inputString.Length != numberColumns)
                    {
                        Console.WriteLine("Введено не верное количество цифр.");
                        Console.WriteLine("Введите элементы матрицы последней ввёденной строки:");
                    }
                    else
                    {
                        inputMatrix = CheckStringInput(numberColumns, ref exit, inputMatrix, inputString, i);
                    }
                } while ((inputString.Length != numberColumns) || (!exit));
            }
            return inputMatrix;
        }

        /// <summary>
        /// Метод проверяет корректна ли введенная строка.
        /// </summary>
        /// <param name="numberColumns"> Количество столбцов. </param>
        /// <param name="exit"> Отвечает за корректность элементов. </param>
        /// <param name="inputMatrix"> Массив в который записывается матрица. </param>
        /// <param name="inputString"> Массив всех строк, получившихся после операции разделение строки до пробела. </param>
        /// <param name="numberString"> Проверяемая строка. </param>
        /// <returns> Возвращает массив в котором храниться матрица. </returns>
        private static double[,] CheckStringInput(int numberColumns, ref bool exit, double[,] inputMatrix, string[] inputString, int numberString)
        {
            double matrixElement;
            for (int j = 0; j < numberColumns; j++)
            {
                // Проверка является ли число типом double у которого после запятой знак.
                if (!double.TryParse(inputString[j], out matrixElement) || (((double)(10 * matrixElement - (int)(10 * matrixElement) / 1) != 0)))
                {
                    Console.WriteLine("Введено неподходящее значение.");
                    Console.WriteLine("Введите элементы матрицы последней ввёденной строки:");
                    exit = false;
                }
                else
                {
                    inputMatrix[numberString, j] = matrixElement;
                    // Проверка лежит ли число в диапазоне от 0 до 10.
                    if ((matrixElement < 0) || (matrixElement > 10))
                    {
                        Console.WriteLine("Некоторые числа не принадлежат диапазону от 0 до 10.");
                        Console.WriteLine("Введите элементы матрицы последней ввёденной строки:");
                        exit = false;
                    }
                }
            }

            return inputMatrix;
        }

        /// <summary>
        /// Считывает из файла массив, до того пока он не станет корректным.
        /// </summary>
        /// <param name="numberString"> Количетво строк, которое должно быть в матрице. </param>
        /// <param name="numberColumns"> Количество столбцов, которое должно быть в матрице. </param>
        /// <returns> Возвращает корректный массив. </returns>
        static double[,] ReadingFile(int numberString, int numberColumns)
        {
            // Файл из которого программа считывает называется input. Лежит в Matr:ConsoleApp1:bin:Debug:net5.0.
            string[] lines;
            bool exit;
            var matrix = new double[numberString, numberColumns];
            string[] inputString;
            do
            {
                exit = true;
                lines = File.ReadAllLines("input.txt");
                if (lines.Length != numberString)
                {
                    Console.WriteLine("Размер массива неверный, измените файл, не забудьте сохранить и нажмите Enter.");
                    string pause = Console.ReadLine();
                    exit = false;
                }
                else
                {
                    for (int i = 0; i < numberString; i++)
                    {
                        inputString = lines[i].Split(' ');
                        // Проверка верное ли количество значений введенно.
                        if (inputString.Length != numberColumns)
                        {
                            Console.WriteLine("В строке неверное количество цифр.");
                            Console.WriteLine("Измените файл, не забудьте сохранить и нажмите Enter.");
                            // Ожидание ввода строки.
                            string pause = Console.ReadLine();
                            exit = false;
                        }
                        else
                        {
                            matrix= CheckStringFile(numberColumns, ref exit, matrix, inputString, i);
                        }
                    }
                }
            } while ((lines.Length != numberString) || (!exit));
            return matrix;
        }

        /// <summary>
        /// Метод проверяет корректные ли данные в строке файла, если да, то записывает в массив.
        /// </summary>
        /// <param name="numberColumns"> Количество столбцов. </param>
        /// <param name="exit"> Отвечает за то корректные ли данные в файле. </param>
        /// <param name="matrix"> Массив в который записывается матрица. </param>
        /// <param name="inputString"> Массив строк из файла. </param>
        /// <param name="numberLine"> Номер строки, которая проверяется. </param>
        /// <returns> Возвращает массив в котором хранится матрица. </returns>
        private static double[,] CheckStringFile(int numberColumns, ref bool exit, double[,] matrix, string[] inputString, int numberLine)
        {
            double matrixElement;
            for (int j = 0; j < numberColumns; j++)
            {
                // Проверка является ли число типом double у которого после запятой знак.
                if (!double.TryParse(inputString[j], out matrixElement) || (((double)(10 * matrixElement - (int)(10 * matrixElement) / 1) != 0)))
                {
                    Console.WriteLine("Введено неподходящее значение.");
                    Console.WriteLine("Измените файл, не забудьте сохранить и нажмите Enter.");
                    // Ожидание ввода строки.
                    string pause = Console.ReadLine();
                    exit = false;
                }
                else
                {
                    matrix[numberLine, j] = matrixElement;
                    // Проверка лежит ли число в диапазоне от 0 до 10.
                    if ((matrixElement < 0) || (matrixElement > 10))
                    {
                        Console.WriteLine("Некоторые числа не принадлежат диапазону от 0 до 10.");
                        Console.WriteLine("Измените файл и нажмите Enter.");
                        // Ожидание ввода строки.
                        string pause = Console.ReadLine();
                        exit = false;
                    }
                }
            }
            return matrix;
        }

        /// <summary>
        /// Выполнение транспонирование матрицы.
        /// </summary>
        static void Transponition()
        {
            Console.Write("Введите количество строк матрицы:");
            int numberString = Size();
            Console.Write("Введите количество столбцов матрицы:");
            int numberColumns = Size();
            var matrix = InputOrRandom(numberString, numberColumns);
            Console.WriteLine("Результат:");
            // Вывод транспонированной матрицы.
            for (int i = 0; i < numberColumns; i++)
            {
                for (int j = 0; j < numberString - 1; j++)
                {
                    Console.Write(matrix[j, i] + " ");
                }
                Console.WriteLine(matrix[numberString - 1, i]);
            }
        }

        /// <summary>
        /// Ввод корректного размера матрицы.
        /// </summary>
        /// <returns> Возвращает корректный размер матрицы. </returns>
        static int Size()
        {
            int numberMatrix;
            string inputString;
            // Выполнения до того пока не будет введенно корректные данные.
            do
            {
                inputString = Console.ReadLine();
                // Проверка подходит ли значение под размер матрицы.
                if (!int.TryParse(inputString, out numberMatrix) || (numberMatrix < 1) || (numberMatrix > 10))
                {
                    Console.WriteLine("Введено некорректное значение");
                    Console.Write("Введите ещё раз:");
                }
            } while (!int.TryParse(inputString, out numberMatrix) || (numberMatrix < 1) || (numberMatrix > 10));
            return numberMatrix;
        }

        /// <summary>
        /// Выполнение операции нахождение следа матрицы.
        /// </summary>
        static void Track()
        {
            double trackMatrix = 0;
            Console.Write("Введите размер квадратной матрицы:");
            int sizeMatrix = Size();
            var matrix = InputOrRandom(sizeMatrix, sizeMatrix);
            // Подсчёт следа матрицы.
            for (int i = 0; i < sizeMatrix; i++)
            {
                trackMatrix += matrix[i, i];
            }
            Console.Write("След матрицы:");
            Console.WriteLine(trackMatrix);
        }

        /// <summary>
        /// Функция рандомно по выбору пользователя генерирует две матрицы или позволяет пользователю их ввести. 
        /// </summary>
        /// <param name="firstNumberString"> Количество строк первой матрицы. </param>
        /// <param name="firstNumberColumns"> Количество столбцов первой матрицы. </param>
        /// <param name="secondNumberString"> Количество строк второй матрицы. </param>
        /// <param name="secondNumberColumns"> Количество столбцов второй матрицы. </param>
        /// <returns></returns>
        static (double[,], double[,]) InputOrRandomTwoMatrix(int firstNumberString, int firstNumberColumns, int secondNumberString, int secondNumberColumns)
        {
            var exit = false;
            var firstMatrix = new double[firstNumberString, firstNumberColumns];
            var secondMatrix = new double[secondNumberString, secondNumberColumns];
            // Выполнение пока не будет введенно 1 или 2.
            do
            {
                Console.WriteLine("Введите 1, чтобы ввести вручную, 2 - чтобы матрица была рандомной:");
                string inputString = Console.ReadLine();
                // Если вводится 1, то пользователь вводит матрицы.
                if (inputString == "1")
                {
                    firstMatrix = Input(firstNumberString, firstNumberColumns);
                    secondMatrix = Input(secondNumberString, secondNumberColumns);
                    exit = true;
                }
                else
                {
                    // Если вводится 2, то матрица рандомно генерируется.
                    if (inputString == "2")
                    {
                        Console.WriteLine("Первая матрица:");
                        firstMatrix = Random(firstNumberString, firstNumberColumns);
                        Console.WriteLine("Вторая матрица:");
                        secondMatrix = Random(secondNumberString, secondNumberColumns);
                        exit = true;
                    }
                }
            } while (!exit);
            return (firstMatrix, secondMatrix);
        }

        /// <summary>
        /// Выполение операции суммирование двух матриц.
        /// </summary>
        static void Summ()
        {
            Console.Write("Введите количество строк в матрицах:");
            int numberString = Size();
            Console.Write("Введите количество столбцов в матрицах:");
            int numberColumns = Size();
            var twoMatrix = InputOrRandomTwoMatrix(numberString, numberColumns, numberString, numberColumns);
            var firstMatrix = twoMatrix.Item1;
            var secondMatrix = twoMatrix.Item2;
            Console.WriteLine("Сумма матриц:");
            // Вывод матрицы равной сумме двух матриц.
            for (int i = 0; i < numberString; i++)
            {
                for (int j = 0; j < numberColumns - 1; j++)
                {
                    Console.Write(firstMatrix[i, j] + secondMatrix[i, j] + " ");
                }
                Console.WriteLine(firstMatrix[i, numberColumns - 1] + secondMatrix[i, numberColumns - 1]);
            }
        }

        /// <summary>
        /// Выполнение операции вычитание матрицы.
        /// </summary>
        static void Difference()
        {
            Console.Write("Введите количество строк в матрицах:");
            int numberString = Size();
            Console.Write("Введите количество столбцов в матрицах:");
            int numberColumns = Size();
            var twoMatrix = InputOrRandomTwoMatrix(numberString, numberColumns, numberString, numberColumns);
            var firstMatrix = twoMatrix.Item1;
            var secondMatrix = twoMatrix.Item2;
            Console.WriteLine("Разность матриц:");
            // Вывод матрицы равной разности двух матриц.
            for (int i = 0; i < numberString; i++)
            {
                for (int j = 0; j < numberColumns - 1; j++)
                {
                    Console.Write(firstMatrix[i, j] - secondMatrix[i, j] + " ");
                }
                Console.WriteLine(firstMatrix[i, numberColumns - 1] - secondMatrix[i, numberColumns - 1]);
            }
        }

        /// <summary>
        /// Выполнение операции произведение двух матриц. 
        /// </summary>
        static void MatrixProduct()
        {
            double result = 0;
            Console.Write("Введите количество строк первой матрицы:");
            int firstNumberString = Size();
            Console.Write("Введите количество столбцов первой матрицы:");
            int firstNumberColumns = Size();
            Console.Write("Введите количество столбцов второй матрицы:");
            int secondNumberColumns = Size();
            // Заполняем массивы, которые являются матрицами.;
            var twoMatrix = InputOrRandomTwoMatrix(firstNumberString, firstNumberColumns, firstNumberColumns, secondNumberColumns);
            var firstMatrix = twoMatrix.Item1;
            var secondMatrix = twoMatrix.Item2;
            Console.WriteLine("Произведение двух матриц:");
            // Вывод матрицы, являющейся результатом умножения двух заданных матриц.
            for (int i = 0; i < firstNumberString; i++)
            {
                for (int j = 0; j < secondNumberColumns - 1; j++)
                {
                    // Перемножаем строку и столбец заданных матриц.
                    for (int g = 0; g < firstNumberColumns; g++)
                    {
                        result += firstMatrix[i, g] * secondMatrix[g, j];
                    }
                    // Выводим в одной строке через пробел первую строчку, кроме последнего элемента.
                    Console.Write("{0,8:N3}", result);
                    Console.Write(" ");
                    result = 0;
                }
                result = 0;
                // Выводим последний элемент и переходим на новую строку.
                for (int g = 0; g < firstNumberColumns; g++)
                {
                    result += firstMatrix[i, g] * secondMatrix[g, secondNumberColumns - 1];
                }
                Console.WriteLine("{0,8:N3}", result);
                result = 0;
            }
        }

        /// <summary>
        /// Выполнение операции умножение матрицы на число.
        /// </summary>
        static void MultiplicationNumber()
        {
            var exit = false;
            Console.Write("Введите количество строк матрицы:");
            int numberString = Size();
            Console.Write("Введите количество столбцов матрицы:");
            int numberColumns = Size();
            var matrix = InputOrRandom(numberString, numberColumns);
            Console.Write("Введите число на которое надо будет умножить матрицу:");
            string inputNumber;
            double number;
            // Зацикливаем, пока пользователь не введёт корректное значение.
            do
            {
                inputNumber = Console.ReadLine();
                // Переменная valueDouble чтобы в строке с условием не было больше 120 символов.
                bool valueDouble = !double.TryParse(inputNumber, out number);
                if ((valueDouble) || (((double)(10 * number - (int)(10 * number) / 1) != 0)))
                {
                    Console.WriteLine("Введено некорректное значение:");
                    Console.WriteLine("Введите число ещё раз:");
                }
                else
                {
                    exit = true;
                }
            } while (!exit);
            // Выводим результат с точностью до 2 знаков после запятой.
            for (int i = 0; i < numberString; i++)
            {
                for (int j = 0; j < numberColumns - 1; j++)
                {
                    Console.Write("{0,8:N2}", number * matrix[i, j]);
                    Console.Write(" ");
                }
                Console.WriteLine("{0,8:N2}", number * matrix[i, numberColumns - 1]);
            }
        }

        /// <summary>
        /// Функция в зависимости от решения пользователя либо рандомно генерирует матрицу, либо выполняет ввод матрицы пользователем,
        /// либо читает из файла.
        /// </summary>
        /// <param name="numberString"> Количество строк, которое будет в этой матрице. </param>
        /// <param name="numberColumns"> Количество столбцов, которое будет в этой матрице. </param>
        /// <returns> Возвращает матрицу по заданным параметрам.</returns>
        static double[,] InputOrRandom(int numberString, int numberColumns)
        {
            var matrix = new double[numberString, numberColumns];
            var exit = false;
            // Зацикливаем пока пользователь не введёт 1 или 2.
            do
            {
                Console.WriteLine("Введите 1 - чтобы ввести вручную, 2 - чтобы матрица была рандомной, 3 - чтобы ввести из файла:");
                string inputString = Console.ReadLine();
                // Проверка, что ввёл пользователь.
                if (inputString == "1")
                {
                    // Если пользователь ввёл 1, то выполняем операцию ввод матрицы пользователем, и в exit записываем
                    // true, чтобы выйти.
                    matrix = Input(numberString, numberColumns);
                    exit = true;
                }
                else
                {
                    if (inputString == "2")
                    {
                        // Если пользователь ввёл 2, то выполняем операцию рандомная генерация матрицы, и в exit
                        // записываем true, чтобы выйти.
                        Console.WriteLine("Матрица:");
                        matrix = Random(numberString, numberColumns);
                        exit = true;
                    }
                    else
                    {
                        if (inputString == "3")
                        {
                            matrix = ReadingFile(numberString, numberColumns);
                            exit = true;
                        }
                    }
                }
            } while (!exit);
            return matrix;
        }

        /// <summary>
        /// Убирает из матрицы 1 строку и заданный столбец.
        /// </summary>
        /// <param name="basesMatrix"> Исходная матрица, из которой удаляются элементы. </param>
        /// <param name="sizeMatrix"> Размер исходной матрицы. </param>
        /// <param name="column"> Столбец, который нужно удалить. </param>
        /// <returns> Возвращает обработанную матрицу. </returns>
        static double[,] MatrixSeparation(double[,] basesMatrix, int sizeMatrix, int column)
        {
            // Создаём новый массив в который будем записывать матрицу после удаления.
            var newMatrix = new double[sizeMatrix - 1, sizeMatrix - 1];
            for (int i = 1; i < sizeMatrix; i++)
            {
                for (int j = 0; j < sizeMatrix; j++)
                {
                    // Если j меньше номера столбца который мы удаляем, то в новый массив записываем элемент номер
                    // строки, которого на 1 больше.
                    if (j < column)
                    {
                        newMatrix[i - 1, j] = basesMatrix[i, j];
                    }
                    else
                    {
                        // Если j больше номера столбца который мы удаляем, то в новый массив записываем элемент номер
                        // строки и столбца, которого на 1 больше.
                        if (j > column)
                        {
                            newMatrix[i - 1, j - 1] = basesMatrix[i, j];
                        }
                    }
                }
            }
            return newMatrix;
        }

        /// <summary>
        /// Вычисление определителя матрицы.
        /// </summary>
        /// <param name="matrix"> Матрица у которой ищется определитель. </param>
        /// <param name="sizeMatrix"> Размер матрицы. </param>
        /// <returns> Возвращает определитель этой матрицы. </returns>
        static double Determinant(double[,] matrix, int sizeMatrix)
        {
            double valueDeterminant = 0;
            // Проверка равен ли порядок матрицы 1.
            if (sizeMatrix == 1)
            {
                return matrix[0, 0];
            }
            // Если не равен, то ипользуем теорему Лапласа для 1 строки.
            for (int i = 0; i < sizeMatrix; i++)
            {
                if (i % 2 == 0)
                {
                    // Если номер столбца чётный к определителю прибавляем элемент, стоящий на 1 строке и i столбце,
                    // умноженный на определитель матрицы без 1 строки и этого столбца.
                    valueDeterminant += matrix[0, i] * Determinant(MatrixSeparation(matrix, sizeMatrix, i), sizeMatrix - 1);
                }
                else
                {
                    // Если номер столбца нечётный из определителя вычитаем элемент, стоящий на 1 строке и i столбце,
                    // умноженный на определитель матрицы без 1 строки и этого столбца.
                    valueDeterminant -= matrix[0, i] * Determinant(MatrixSeparation(matrix, sizeMatrix, i), sizeMatrix - 1);
                }
            }
            return valueDeterminant;
        }

        /// <summary>
        /// Выполнение операции нахождение определителя матрицы.
        /// </summary>
        static void СalculationDetermination()
        {
            Console.Write("Введите размер квадратной матрицы:");
            int sizeMatrix = Size();
            var matrix = InputOrRandom(sizeMatrix, sizeMatrix);
            Console.Write("Определитель:");
            Console.WriteLine(Determinant(matrix, sizeMatrix));
        }

        /// <summary>
        /// Функция вычисляет определитель матрицы в которой заданный столбец матрицы системы уравнений заменяется
        /// на свободные коэффициенты уравнения.
        /// </summary>
        /// <param name="basesMatrix"> Исходная матрица. </param>
        /// <param name="freeCoefficient"> Свободные коэффициенты уравнения. </param>
        /// <param name="sizeMatrix"> Размер матрицы. </param>
        /// <param name="column"> Столбец,который заменяется. </param>
        /// <returns> Возвращает определитель такой матрицы. </returns>
        static double AuxiliaryMatrices(double[,] basesMatrix, double[,] freeCoefficient, int sizeMatrix, int column)
        {
            // Копируем массив, используя глубокое копирование, чтобы можно было менять элементы только новый массив.
            var resultMatrix = (double[,])basesMatrix.Clone();
            // Заменяем столбец Column на свободные коэффициенты уравнения.
            for (int j = 0; j < sizeMatrix; j++)
            {
                resultMatrix[j, column] = freeCoefficient[0, j];
            }
            return Determinant(resultMatrix, sizeMatrix);
        }

        /// <summary>
        /// Выполнение операции решение СЛАУ методом Крамера.
        /// </summary>
        static void Kramers()
        {
            Console.WriteLine("В квадратной матрице находятся только коэффициенты перед переменными.");
            Console.Write("Введите размер квадратной матрицы:");
            int numberEquations = Size();
            var zeroDetermination = true;
            // Массив определителей вспомогательных матриц.
            var determinationAuxiliaryMatrices = new double[numberEquations];
            var matrixCoefficient = InputOrRandom(numberEquations, numberEquations);
            Console.WriteLine("Введите свободные коэффициенты уравнений через пробел:");
            var freeCoefficients = Input(1, numberEquations);
            double systemDeterminant = Determinant(matrixCoefficient, numberEquations);
            // Записываем определители всех вспомогательных матриц в массив determinationAuxiliaryMatrices.
            for (int i = 0; i < numberEquations; i++)
            {
                determinationAuxiliaryMatrices[i] = AuxiliaryMatrices(matrixCoefficient, freeCoefficients, numberEquations, i);
            }
            // Проверка равен ли определитель системы 0.
            if (systemDeterminant == 0)
            {
                // Определяем все ли определители вспомогательных матриц равны 0.
                for (int i = 0; i < numberEquations; i++)
                {
                    if (determinationAuxiliaryMatrices[i] != 0)
                    {
                        zeroDetermination = false;
                    }
                }
                // Если все определители равны 0, выводим что решений бесконечно, иначе что решений нет.
                if (zeroDetermination)
                {
                    Console.WriteLine("Бесконечно много решений");
                }
                else
                {
                    Console.WriteLine("Нет решений");
                }
            }
            else
            {
                // Если не равен, то выводим решения системы с точностью до 3 знаков после запятой.
                for (int i = 0; i < numberEquations; i++)
                {
                    Console.Write($"x{i + 1}={determinationAuxiliaryMatrices[i] / systemDeterminant:N3} ");
                }
            }
        }

        /// <summary>
        /// Точка входа.
        /// </summary>
        static void Main()
        {
            Console.WriteLine("Файл лежит в Matr:ConsoleApp1:bin:Debug:net5.0.");
            Console.WriteLine("В матрице могут быть числа от 0 до 10 с 1 знаком после запятой.");
            Console.Write("Каждая строка матрицы вводится в одной строке через пробел, после последнего ");
            Console.WriteLine("числа пробел не ставить.");
            Console.WriteLine("Новая строка матрицы с новой строки.");
            Console.WriteLine("В файле находится только матрица.");
            Console.WriteLine("Файл называется input.");
            Console.WriteLine("Максимальный размер матрицы 10.");
            Console.WriteLine("Чтобы найти след матрицы введите 1.");
            Console.WriteLine("Чтобы транспонировать матрицу введите 2.");
            Console.WriteLine("Чтобы найти сумму матриц нажмите 3.");
            Console.WriteLine("Чтобы найти разность матриц нажмите 4.");
            Console.WriteLine("Чтобы найти произведение матриц нажмите 5.");
            Console.WriteLine("Чтобы умножить матрицу на число нажмите 6.");
            Console.WriteLine("Чтобы найти определитель матрицы нажмите 7.");
            Console.WriteLine("Чтобы решить СЛАУ методом Крамера нажмите 8.");
            // Зацикливаем до того момента пока пользователь при окончании не нажмёт Escape.
            do
            {
                Console.Write("Выберите действие:");
                string inputString = Console.ReadLine();
                // В зависимости от того, что выбрал пользователь выполняем определённое действие.
                switch (inputString)
                {
                    case "1":
                        // Выполнение операции нахождение следа.
                        Track();
                        break;
                    case "2":
                        // Выполнение операции транспонирование матрицы.
                        Transponition();
                        break;
                    case "3":
                        // Выполнение операции сложение двух матриц.
                        Summ();
                        break;
                    case "4":
                        // Выполнение операции вычитание двух матриц.
                        Difference();
                        break;
                    case "5":
                        // Выполнение операции умножение двух матриц.
                        MatrixProduct();
                        break;
                    case "6":
                        // Выполнение операции умножение матрицы на число.
                        MultiplicationNumber();
                        break;
                    case "7":
                        // Выполнение операции нахождение определителя матрицы. 
                        СalculationDetermination();
                        break;
                    case "8":
                        // Выполение операции решение СЛАУ методом Крамера.
                        Kramers();
                        break;
                    default:
                        Console.WriteLine("Такого действия нет.");
                        break;
                }
                Console.WriteLine("Чтобы выйти из игры нажмите Escape, для продолжения нажмите любую другую клавишу.");
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
        }
    }
}
